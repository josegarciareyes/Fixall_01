package com.registro.usuarios.repositorio;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.Especializacion;
import com.registro.usuarios.modelo.Servicio;
import com.registro.usuarios.modelo.Usuario;

@Repository
public interface ServicioRepositorio extends JpaRepository<Servicio, Long> {

    // Servicios registrados por un cliente específico
    List<Servicio> findByUsuario(Usuario usuario);

    // Servicios por una especialización específica
    List<Servicio> findByEspecializacion(Especializacion especializacion);

    // ✅ Servicios visibles para un técnico:
    // - Pendientes de su especialización
    // - Ya asignados a él
    @Query("SELECT s FROM Servicio s " +
           "WHERE s.especializacion.id IN :idsEspecializaciones " +
           "AND (LOWER(s.estado.nombre) = 'pendiente' OR s.tecnico.email = :emailTecnico)")
    List<Servicio> findServiciosParaTecnico(
        @Param("idsEspecializaciones") Set<Long> idsEspecializaciones,
        @Param("emailTecnico") String emailTecnico
    );
}
