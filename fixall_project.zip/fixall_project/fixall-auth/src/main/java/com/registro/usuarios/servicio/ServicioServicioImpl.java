package com.registro.usuarios.servicio;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.controlador.dto.ServicioRegistroDTO;
import com.registro.usuarios.modelo.DetalleServicio;
import com.registro.usuarios.modelo.Especializacion;
import com.registro.usuarios.modelo.Estado;
import com.registro.usuarios.modelo.Servicio;
import com.registro.usuarios.modelo.TipoServicio;
import com.registro.usuarios.modelo.Usuario;
import com.registro.usuarios.repositorio.EspecializacionRepositorio;
import com.registro.usuarios.repositorio.EstadoRepositorio;
import com.registro.usuarios.repositorio.ServicioRepositorio;
import com.registro.usuarios.repositorio.TipoServicioRepositorio;
import com.registro.usuarios.repositorio.UsuarioRepositorio;

@Service
public class ServicioServicioImpl {

    @Autowired
    private ServicioRepositorio servicioRepositorio;

    @Autowired
    private TipoServicioRepositorio tipoServicioRepositorio;

    @Autowired
    private EstadoRepositorio estadoRepositorio;

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Autowired
    private EspecializacionRepositorio especializacionRepositorio;

    // ✅ Registro de nuevo servicio por parte del cliente
    public void registrarServicio(String emailUsuario, ServicioRegistroDTO registroDTO) {
        Usuario usuario = usuarioRepositorio.findByEmail(emailUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        TipoServicio tipoServicio = tipoServicioRepositorio.findById(registroDTO.getTipoServicioId())
                .orElseThrow(() -> new RuntimeException("Tipo de Servicio no encontrado"));

        Estado estadoPendiente = estadoRepositorio.findByNombre("Pendiente")
                .orElseThrow(() -> new RuntimeException("Estado no encontrado"));

        Especializacion especializacion = especializacionRepositorio.findById(registroDTO.getEspecializacionId())
                .orElseThrow(() -> new RuntimeException("Especialización no encontrada"));

        DetalleServicio detalleServicio = new DetalleServicio(registroDTO.getDescripcion(), LocalDateTime.now());

        Servicio servicio = new Servicio(usuario, null, tipoServicio, detalleServicio, estadoPendiente, especializacion);

        detalleServicio.setServicio(servicio); // Relación bidireccional

        servicioRepositorio.save(servicio);

        // 🔎 Log
        System.out.println("✅ Servicio registrado con éxito: ID=" + servicio.getId() +
                " | Estado=" + servicio.getEstado().getNombre() +
                " | Especialización=" + servicio.getEspecializacion().getNombre() +
                " | Usuario=" + servicio.getUsuario().getEmail());
    }

    // ✅ Servicios del cliente autenticado
    public List<Servicio> obtenerServiciosPorUsuario(String emailUsuario) {
        Usuario usuario = usuarioRepositorio.findByEmail(emailUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        List<Servicio> servicios = servicioRepositorio.findByUsuario(usuario);

        // 🔎 Log
        System.out.println("? Servicios registrados por cliente: " + usuario.getEmail());
        for (Servicio s : servicios) {
            String tecnicoEmail = (s.getTecnico() != null) ? s.getTecnico().getEmail() : "SIN ASIGNAR";
            System.out.println("   -> Servicio ID=" + s.getId() +
                    " | Estado=" + s.getEstado().getNombre() +
                    " | Especialización=" + s.getEspecializacion().getNombre() +
                    " | Técnico=" + tecnicoEmail);
        }

        return servicios;
    }

    // ✅ Todos los servicios en general (opcional)
    public List<Servicio> obtenerTodosLosServicios() {
        return servicioRepositorio.findAll();
    }

    // ✅ Servicios visibles para un técnico (pendientes o ya tomados por él)
    public List<Servicio> obtenerServiciosParaTecnico(String emailTecnico) {
        Usuario tecnico = usuarioRepositorio.findByEmail(emailTecnico)
                .orElseThrow(() -> new RuntimeException("Técnico no encontrado"));

        Set<Especializacion> especializaciones = tecnico.getEspecializaciones();

        // 🔎 Log técnico autenticado
        System.out.println("? Técnico autenticado: " + tecnico.getEmail());
        String nombreMostrar = (tecnico.getDatosPersonales() != null)
                ? tecnico.getDatosPersonales().getNombre()
                : "(Sin nombre asignado)";
        System.out.println("   Nombre técnico: " + nombreMostrar);

        System.out.println("? Especializaciones del técnico:");
        for (Especializacion e : especializaciones) {
            System.out.println("   - ID=" + e.getId() + " | Nombre=" + e.getNombre());
        }

        // ✅ Consulta repositorio
        Set<Long> idsEspecializaciones = especializaciones.stream().map(Especializacion::getId).collect(java.util.stream.Collectors.toSet());
        List<Servicio> servicios = servicioRepositorio.findServiciosParaTecnico(idsEspecializaciones, emailTecnico);

        // 🔎 Log servicios encontrados
        System.out.println("? Servicios encontrados para técnico: " + servicios.size());
        for (Servicio s : servicios) {
            String clienteNombre = (s.getUsuario().getDatosPersonales() != null)
                    ? s.getUsuario().getDatosPersonales().getNombre()
                    : "SIN NOMBRE";
            String tecnicoEmail = (s.getTecnico() != null) ? s.getTecnico().getEmail() : "SIN ASIGNAR";

            System.out.println("   -> Servicio ID=" + s.getId() +
                    " | Estado=" + s.getEstado().getNombre() +
                    " | Especialización=" + s.getEspecializacion().getNombre() +
                    " | Cliente=" + clienteNombre +
                    " | Técnico=" + tecnicoEmail);
        }

        return servicios;
    }

    // ✅ Lógica de actualización de estado del servicio por parte del técnico
    public void actualizarEstadosServicios(Long servicioId, Long estadoId, String emailTecnico) {
        Servicio servicio = servicioRepositorio.findById(servicioId)
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

        Estado nuevoEstado = estadoRepositorio.findById(estadoId)
                .orElseThrow(() -> new RuntimeException("Estado no encontrado"));

        Usuario tecnico = usuarioRepositorio.findByEmail(emailTecnico)
                .orElseThrow(() -> new RuntimeException("Técnico no encontrado"));

        Estado estadoActual = servicio.getEstado();

        boolean esMismoTecnico = servicio.getTecnico() != null &&
                servicio.getTecnico().getEmail().equalsIgnoreCase(emailTecnico);

        if ("Pendiente".equalsIgnoreCase(estadoActual.getNombre()) && servicio.getTecnico() == null) {
            servicio.setTecnico(tecnico);
        }

        if (estadoActual.equals(nuevoEstado)) {
            return;
        }

        if ("Cancelado".equalsIgnoreCase(nuevoEstado.getNombre())) {
            servicio.setTecnico(tecnico);
            servicio.setEstado(nuevoEstado);
            servicio.setFechaUltimaActualizacion(LocalDateTime.now());
            servicioRepositorio.save(servicio);
            return;
        }

        if (esMismoTecnico || servicio.getTecnico() == null) {
            servicio.setEstado(nuevoEstado);
            servicio.setTecnico(tecnico);
            servicio.setFechaUltimaActualizacion(LocalDateTime.now());
            servicioRepositorio.save(servicio);
        }
    }
}
